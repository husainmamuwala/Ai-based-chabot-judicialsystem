import './App.css';
import Basic from "./components/Basic"

function App() {
  return (
    <div className="App">
      <Basic />
    </div>
  );
}

export default App;
